"""Shared pixel UI. Rendering only: no simulation or input state lives here."""
import pygame as pg

INK = (23, 45, 49)
PANEL = (35, 64, 67)
EDGE = (105, 150, 141)
CREAM = (250, 246, 225)
MUTED = (184, 208, 199)
GREEN = (144, 232, 184)
GOLD = (255, 204, 103)
RED = (245, 116, 109)


class PixelFont:
    # Keep the pixel-art panels and game world, while using a familiar UI face
    # so long instructions, names and status values stay easy to read.
    symbols = str.maketrans({'←':'<', '→':'>', '↑':'^', '↓':'v', '↔':'<>',
                            '⚔':'', 'ⓘ':'i', '▶':'>', '●':'*', '○':'o', '−':'-', '–':'-', '…':'...'})

    def __init__(self, size):
        self.source = pg.font.SysFont('Arial', size)

    def render(self, text, antialias, color, background=None):
        return self.source.render(str(text).translate(self.symbols), True, color, background)

    def size(self, text):
        return self.source.size(str(text).translate(self.symbols))

    def get_linesize(self):
        return self.source.get_linesize()


def font(size):
    return PixelFont(size)


def panel(surface, rect, color, border=None):
    r = pg.Rect(rect)
    if r.width <= 0 or r.height <= 0:
        return
    if r.height < 20:
        pg.draw.rect(surface, color, r)
        return
    # Map legacy dark panels into one coherent palette; keep semantic accents.
    if max(color[:3]) < 120:
        color = INK if sum(color[:3]) < 130 else PANEL
    light = sum(color[:3]) > 570
    outline = border or (EDGE if not light else GOLD)
    pg.draw.rect(surface, (15, 32, 34), r.move(2, 3), border_radius=6)
    pg.draw.rect(surface, outline, r, border_radius=6)
    pg.draw.rect(surface, color, r.inflate(-4, -4), border_radius=4)
    pg.draw.line(surface, (255, 255, 245) if light else (64, 96, 93),
                 (r.left + 4, r.top + 4), (r.right - 5, r.top + 4), 2)


def pixelate(surface, factor=2):
    size = surface.get_size()
    tiny = pg.transform.scale(surface, (max(1, size[0]//factor), max(1, size[1]//factor)))
    pg.transform.scale(tiny, size, surface)


def meter(surface, rect, value, maximum, color=GREEN):
    r = pg.Rect(rect)
    pg.draw.rect(surface, (10, 17, 32), r)
    inner = r.inflate(-4, -4)
    fill = inner.copy()
    fill.width = round(inner.width * max(0, min(1, value / max(1, maximum))))
    if fill.width:
        pg.draw.rect(surface, color, fill)
        pg.draw.line(surface, CREAM, fill.topleft, (fill.right-1, fill.top), 1)
    for x in range(inner.left + 12, inner.right, 14):
        pg.draw.line(surface, INK, (x, inner.top), (x, inner.bottom-1), 2)


_ARENAS = {}

def arena(surface, style):
    """Four cached pixel stages; artwork is built once, not each combat frame."""
    if style not in _ARENAS:
        stage = pg.Surface((1280,800))
        palette = {
            'meadow':((30,55,74),(57,97,107),(38,70,73),(87,145,100),(41,54,65)),
            'water':((27,48,81),(56,100,134),(33,74,103),(91,177,194),(35,58,84)),
            'cave':((19,20,39),(44,39,66),(30,30,50),(165,130,193),(37,31,55)),
            'sky':((45,76,111),(103,151,176),(61,106,140),(196,213,207),(52,68,94)),
        }
        sky,far,near,edge,floor=palette.get(style,palette['meadow'])
        stage.fill(sky)
        for row in range(12):
            color=tuple(min(255,v+row*2) for v in sky)
            pg.draw.rect(stage,color,(0,row*51,1280,51))
        for i in range(28):
            x=(i*197+53)%1280;y=230+(i*83)%200
            pg.draw.rect(stage,tuple(min(255,c+38) for c in sky),(x,y,2,2))
        for offset,color,base in ((0,far,515),(110,near,580)):
            for i in range(10):
                x=i*165-offset;peak=base-80-(i*71%115)
                pg.draw.polygon(stage,color,[(x-50,base),(x+10,peak+48),(x+40,peak+48),(x+65,peak),(x+93,peak),(x+120,peak+40),(x+205,base)])
        if style=='cave':
            for i in range(9):
                x=i*167+19;height=65+(i*37)%105
                pg.draw.polygon(stage,(71,68,113),[(x,606),(x+18,606-height),(x+34,590-height),(x+48,606)])
                pg.draw.line(stage,(133,169,199),(x+18,606-height),(x+28,594),3)
        elif style=='water':
            pg.draw.rect(stage,(43,98,127),(0,520,1280,86))
            for i in range(40):
                x=(i*113)%1280;y=532+(i*37)%60
                pg.draw.rect(stage,(72,137,158),(x,y,24+(i%3)*10,3))
            for x in (80,1140):
                pg.draw.rect(stage,(90,106,119),(x,387,34,218))
                pg.draw.rect(stage,(151,156,161),(x-12,378,58,14))
                pg.draw.rect(stage,(91,177,194),(x+7,410,20,46))
        else:
            # Ruined columns and tournament pennants give the stage depth.
            for x in (92,1110):
                pg.draw.rect(stage,(64,81,94),(x,384,50,222))
                pg.draw.rect(stage,(121,137,140),(x-9,374,68,15))
                pg.draw.rect(stage,(91,108,116),(x+5,396,8,185))
                pg.draw.line(stage,(184,167,118),(x+26,304),(x+26,389),3)
                pg.draw.polygon(stage,(171,79,94),[(x+29,309),(x+90,321),(x+29,342)])
            for i in range(13):
                x=i*111-22
                pg.draw.rect(stage,(37,72,65),(x,579,74,27))
                pg.draw.rect(stage,(54,94,77),(x+9,568,48,14))
        pg.draw.rect(stage,floor,(0,606,1280,194))
        pg.draw.rect(stage,edge,(0,606,1280,7))
        pg.draw.rect(stage,tuple(max(0,c-25) for c in edge),(0,613,1280,8))
        for y in range(632,800,36):
            for x in range(-60+(y//36%2)*58,1280,116):
                pg.draw.rect(stage,tuple(min(255,c+8) for c in floor),(x,y,110,29),1)
        _ARENAS[style]=stage
    surface.blit(_ARENAS[style],(0,0))


class IconFont:
    """Browser-safe pixel pictograms for the game's existing emoji prompts."""
    def __init__(self, size):
        self.pixels = max(12, int(size))
        self.cache = {}

    @staticmethod
    def _box(surface, color, x, y, w, h, width=0):
        pg.draw.rect(surface, color, (x, y, w, h), width)

    def _icon(self, text):
        size = self.pixels
        icon = pg.Surface((size, size), pg.SRCALPHA)
        q = max(1, size // 20)
        def p(value): return int(value * q)
        def rect(color, x, y, w, h, width=0):
            pg.draw.rect(icon, color, (p(x), p(y), p(w), p(h)), p(width) if width else 0)
        def line(color, points, width=1):
            pg.draw.lines(icon, color, False, [(p(x), p(y)) for x, y in points], p(width))
        def poly(color, points):
            pg.draw.polygon(icon, color, [(p(x), p(y)) for x, y in points])
        def ellipse(color, x, y, w, h, width=0):
            pg.draw.ellipse(icon, color, (p(x), p(y), p(w), p(h)), p(width) if width else 0)

        # Preserve the meaning and colour of the real emoji, rather than
        # silently substituting missing-font tofu boxes.
        if text in ("🔥", "🌋"):
            poly((176, 45, 32), [(10,19),(3,14),(8,3),(12,10),(15,1),(18,12),(16,18)])
            poly((255, 178, 43), [(10,17),(7,13),(11,7),(13,13),(15,15)])
        elif text in ("💧", "💦", "🌊", "🌧"):
            poly((59, 154, 224), [(10,2),(4,12),(4,16),(7,19),(13,19),(16,16),(16,12)])
            ellipse((173, 234, 255), 7, 11, 4, 5)
        elif text in ("🍃", "🌿", "🍀"):
            line((47, 106, 45), [(10,18),(10,7)], 2)
            ellipse((68, 180, 79), 2, 5, 9, 7)
            ellipse((94, 205, 86), 9, 2, 8, 9)
        elif text == "⚡":
            poly((255, 215, 49), [(12,1),(4,11),(9,11),(7,19),(17,7),(12,7)])
            line((183, 113, 27), [(12,1),(4,11),(9,11)], 1)
        elif text in ("❄", "❄️", "☃"):
            for a, b in (((10,1),(10,19)),((2,5),(18,15)),((18,5),(2,15))): line((125,221,255), [a,b], 2)
        elif text in ("🪨",):
            poly((112, 91, 78), [(3,16),(5,8),(11,4),(17,8),(18,15),(14,19),(6,19)])
            poly((163, 139, 116), [(6,10),(11,6),(15,10),(12,13),(7,13)])
        elif text in ("💥", "💢", "💫"):
            poly((255, 202, 41), [(10,1),(12,7),(18,4),(14,10),(19,12),(13,13),(14,19),(10,15),(5,19),(6,13),(1,11),(6,9),(3,4),(8,7)])
            ellipse((243, 88, 55), 8, 8, 4, 4)
        elif text in ("☠", "☠️"):
            ellipse((205, 184, 192), 3, 3, 14, 12)
            ellipse((36, 42, 59), 6, 7, 3, 3); ellipse((36, 42, 59), 12, 7, 3, 3)
            rect((36,42,59), 7, 13, 6, 2)
            line((205,184,192), [(4,18),(16,20)], 2); line((205,184,192), [(16,18),(4,20)], 2)
        elif text in ("🌪", "💨"):
            for y, width in ((5,10),(9,15),(13,12),(17,7)):
                line((187, 231, 236), [(10-width//2,y),(10+width//2,y)], 2)
        elif text == "🔮":
            ellipse((74, 42, 130), 3, 3, 14, 14); ellipse((180, 117, 231), 5, 5, 7, 6)
            rect((232, 206, 111), 6, 17, 8, 2)
        elif text == "🐞":
            ellipse((26, 27, 38), 8, 3, 4, 4); ellipse((221, 59, 49), 4, 6, 12, 12)
            line((36,38,46), [(10,6),(10,18)], 1)
            ellipse((36,38,46), 6, 10, 2, 2); ellipse((36,38,46), 12, 10, 2, 2)
        elif text == "👻":
            ellipse((230, 220, 244), 3, 3, 14, 14)
            poly((230,220,244), [(3,11),(3,18),(6,16),(9,19),(12,16),(16,18),(17,11)])
            ellipse((60,44,87), 6, 8, 2, 3); ellipse((60,44,87), 12, 8, 2, 3)
        elif text in ("🐉",):
            ellipse((71, 168, 98), 4, 5, 12, 12); poly((232, 141, 49), [(5,7),(1,2),(8,5)])
            ellipse((255,238,144), 13, 8, 2, 2)
        elif text == "🌑":
            ellipse((48, 54, 75), 2, 2, 16, 16); ellipse((93, 102, 125), 5, 5, 3, 3)
        elif text == "⚙":
            for angle in range(0, 360, 45):
                # A small square gear is more legible than a missing glyph.
                pass
            rect((153, 169, 181), 4, 4, 12, 12); ellipse((66,77,91), 7, 7, 6, 6)
            rect((153,169,181), 8, 1, 4, 18); rect((153,169,181), 1, 8, 18, 4)
        elif text in ("✨", "⭐", "🏁", "🧬"):
            poly((255, 221, 79), [(10,1),(12,7),(19,10),(12,12),(10,19),(8,12),(1,10),(8,8)])
            if text == "🏁":
                rect((235,235,224), 3, 4, 13, 11); rect((37,49,57), 3, 4, 6, 5); rect((37,49,57), 10, 10, 6, 5)
        elif text == "🎲":
            rect((242, 239, 215), 3, 3, 14, 14); rect((91, 46, 53), 3, 3, 14, 14, 1)
            for x, y in ((6,6),(14,6),(10,10),(6,14),(14,14)): ellipse((190,55,55),x,y,2,2)
        elif text in ("✊", "✋", "✌", "✌️", "🦵", "🥊"):
            ellipse((246, 184, 125), 4, 7, 12, 10)
            if text in ("✋",):
                for x in (5,8,11,14): rect((246,184,125), x, 3, 2, 8)
            elif text in ("✌", "✌️"):
                rect((246,184,125), 6, 2, 3, 8); rect((246,184,125), 11, 2, 3, 8)
        elif text in ("🥤", "🧋", "☕", "🍵", "🧃", "🍹", "🥛"):
            rect((80, 177, 221), 5, 6, 10, 12); rect((225, 242, 247), 5, 5, 10, 2)
            line((239, 99, 102), [(12,1),(10,6)], 2)
        elif text in ("🍜", "🍛", "🍱", "🍕", "🍔", "🍙", "🍲", "🥪"):
            ellipse((234, 177, 76), 3, 9, 14, 8); ellipse((255, 235, 178), 5, 8, 10, 5)
            line((183,72,52), [(7,10),(14,12)], 2)
        else:
            # Unknown emoji: display a clear Poké Ball-like game icon, never a
            # blank/missing-font square.
            ellipse((234, 70, 67), 2, 2, 16, 16)
            rect((241, 240, 224), 2, 10, 16, 2)
            ellipse((246, 245, 230), 7, 7, 6, 6); ellipse((50, 61, 68), 9, 9, 2, 2)
        return icon

    def render(self, text, antialias, color):
        key = (text, tuple(color))
        if key not in self.cache:
            self.cache[key] = self._icon(text)
        return self.cache[key]
