"""Small asynchronous same-origin media loader for the Pygbag build."""
from __future__ import annotations

import asyncio
import queue
import sys

_pending = queue.Queue()
_finished = {"pokemon": queue.Queue(), "audio": queue.Queue()}
_active = set()
_requested = set()


def request(key, url, channel="pokemon"):
    marker = (channel, key)
    if marker not in _requested:
        _requested.add(marker)
        _pending.put((channel, key, url))


def poll(channel="pokemon"):
    try:
        result = _finished[channel].get_nowait()
    except queue.Empty:
        return None
    _requested.discard((channel, result[0]))
    return result


async def _fetch(channel, key, url):
    try:
        from aio.filelike import fopen
        async with fopen(url, "rb") as source:
            data = source.read()
        _finished[channel].put((key, data, ""))
    except Exception as exc:
        _finished[channel].put((key, None, f"{type(exc).__name__}: {exc}"))


async def pump():
    """Start a bounded number of fetches; completed media is read by the game thread."""
    if sys.platform != "emscripten":
        return
    for task in tuple(_active):
        if task.done():
            _active.discard(task)
    try:
        from platform import window
        origin = str(window.location.origin)
    except Exception:
        origin = ""
    while len(_active) < 3:
        try:
            channel, key, url = _pending.get_nowait()
        except queue.Empty:
            break
        task = asyncio.create_task(_fetch(channel, key, origin + url))
        _active.add(task)
