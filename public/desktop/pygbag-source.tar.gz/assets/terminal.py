"""Browser facade for OpenRPG's desktop-only local shell terminal."""
from pathlib import Path


class _Screen:
    def __init__(self, lines: int):
        self.display = [""] * lines
        self.dirty = set(range(lines))


class BrowserTerminal:
    def __init__(self, project, columns=132, lines=36, shell=None):
        self.project = Path(project)
        self.columns, self.lines = columns, lines
        self.screen = _Screen(lines)
        self.error = "The live terminal is available in the desktop edition."
        self.bytes_received = 0
        self.phone_marker = ""
        self.phone_command = ""

    @property
    def shell_name(self):
        return "BROWSER"

    @property
    def running(self):
        return False

    def start(self):
        return None

    def close(self):
        return None

    def poll(self):
        return None

    def send(self, data):
        return None

    def paste(self, data):
        return None

    def scroll(self, amount):
        return None

    def return_to_bottom(self):
        return None

    def run_from_phone(self, command):
        return self.error

    def open_external(self):
        return self.error


ShellTerminal = BrowserTerminal
