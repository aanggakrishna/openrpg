"""Browser entry point for the shared desktop game engine."""
import asyncio
import json
import sys
from pathlib import Path
import pygame as pg
import browser_media

from game_engine import Game, ROOT


async def main():
    save_path = ROOT / ".openrpg" / "save.json"
    save_path.parent.mkdir(parents=True, exist_ok=True)

    # The authenticated Vercel shell passes this account's desktop-format save
    # into the game frame. The same engine then writes it back periodically.
    if sys.platform == "emscripten":
        try:
            from platform import window
            cloud_save = window.parent.OPENRPG_WASM_SAVE
            if cloud_save:
                # The desktop engine supports five independent profiles. Keep
                # those files together in the authenticated web account instead
                # of silently collapsing every profile into the root save.
                bundle = json.loads(str(cloud_save))
                files = bundle.get("files", {}) if bundle.get("format") == "openrpg-web-save-v1" else {}
                allowed = {"save.json", *(f"profiles/slot-{slot}.json" for slot in range(1, 5))}
                if files:
                    for relative, contents in files.items():
                        if relative in allowed:
                            target = save_path.parent / relative
                            target.parent.mkdir(parents=True, exist_ok=True)
                            target.write_text(str(contents), encoding="utf-8")
                else:
                    # Accept existing desktop-format cloud saves during upgrade.
                    save_path.write_text(str(cloud_save), encoding="utf-8")
        except Exception:
            pass

    game = Game(ROOT / "computer-workspace", save_path=save_path)
    if sys.platform == "emscripten":
        try:
            from platform import window
            server_url = str(window.parent.OPENRPG_CONFIG.onlineServerUrl or "/api/online")
            if server_url:
                game.online_url = server_url
        except Exception:
            game.online_url = "/api/online"
    clock = pg.time.Clock()
    last_save = 0.0

    def cloud_bundle():
        files = {}
        paths = [("save.json", save_path)]
        paths.extend((f"profiles/slot-{slot}.json", save_path.parent / "profiles" / f"slot-{slot}.json")
                     for slot in range(1, 5))
        for relative, path in paths:
            try:
                files[relative] = path.read_text(encoding="utf-8")
            except OSError:
                continue
        return json.dumps({"format": "openrpg-web-save-v1", "files": files})

    try:
        while game.running:
            dt = min(.05, clock.tick(60) / 1000)
            for event in pg.event.get():
                game.handle(event)
            game.update(dt)
            game.draw()

            if sys.platform == "emscripten" and game.playing:
                last_save += dt
                if last_save >= 15:
                    last_save = 0
                    game.save_current()
                    try:
                        from platform import window
                        payload = json.dumps({"type": "openrpg-wasm-save",
                                              "save": cloud_bundle()})
                        window.parent.postMessage(payload, "*")
                    except Exception:
                        pass

            await asyncio.sleep(0)
            await browser_media.pump()
    finally:
        game.save_current()
        if sys.platform == "emscripten":
            try:
                from platform import window
                payload = json.dumps({"type": "openrpg-wasm-save",
                                      "save": cloud_bundle()})
                window.parent.postMessage(payload, "*")
            except Exception:
                pass
        game.terminal.close()
        pg.quit()


asyncio.run(main())
