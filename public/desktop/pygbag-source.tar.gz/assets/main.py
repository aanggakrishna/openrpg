"""Asynchronous browser entry point for the unmodified OpenRPG game engine."""
from __future__ import annotations

import asyncio
import sys

import pygame as pg

from game_engine import Game, ROOT
import browser_media


async def main() -> None:
    game = Game(ROOT / "computer-workspace")
    game.begin()
    clock = pg.time.Clock()
    try:
        while game.running:
            dt = min(0.05, clock.tick(60) / 1000)
            for event in pg.event.get():
                game.handle(event)
            game.update(dt)
            game.draw()
            await browser_media.pump()
            await asyncio.sleep(0)
    finally:
        game.save_current()
        game.terminal.close()
        pg.quit()


asyncio.run(main())
