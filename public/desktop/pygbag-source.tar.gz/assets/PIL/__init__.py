"""Minimal Pillow fallback for the browser build.

The browser Pokédex supplies PNG sprites only, so animated GIF decoding is
never requested.  This keeps the desktop engine importable without changing it.
"""


class Image:
    class Resampling:
        NEAREST = 0

    @staticmethod
    def open(*args, **kwargs):
        raise OSError("Animated image decoding is unavailable in the browser build.")
