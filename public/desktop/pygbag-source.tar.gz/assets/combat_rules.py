"""Shared move definitions, usable by the headless online server."""
EMOJI={'normal':'💥','fire':'🔥','water':'💧','grass':'🍃','electric':'⚡','ice':'❄️','ground':'🪨',
       'rock':'🪨','ghost':'👻','psychic':'🔮','poison':'☠️','flying':'🌪️','dark':'🌙','fairy':'✨','steel':'⚙️','bug':'🐛','dragon':'🐉','fighting':'🥊'}
VARIANTS={'wood':'🪵','branch':'🪵','leaf':'🍃','seed':'🌱','vine':'🌿','solar':'☀️','rain':'🌧️',
          'storm':'⛈️','thunder':'⚡','blizzard':'🌨️','snow':'❄️','bubble':'🫧','surf':'🌊','wave':'🌊',
          'swift':'⭐','meteor':'☄️','moon':'🌙','web':'🕸️','wind':'🌪️','sand':'🏜️','mud':'🟤','petal':'🌸'}

# A type is still the authority for damage and effectiveness.  These visual
# variants only make two moves of the same type read differently in battle.
MOVE_EMOJI = {
    'fire': (('blast', '💥'), ('flare', '☀️'), ('meteor', '☄️'), ('burn', '🔥')),
    'water': (('surf', '🌊'), ('wave', '🌊'), ('bubble', '🫧'), ('aqua', '💧'), ('hydro', '💦')),
    'electric': (('thunder', '⚡'), ('volt', '🔋'), ('charge', '⚡'), ('shock', '⚡')),
    'grass': (('seed', '🌱'), ('leaf', '🍃'), ('petal', '🌸'), ('vine', '🌿'), ('solar', '☀️')),
    'ice': (('blizzard', '🌨️'), ('snow', '🌨️'), ('freeze', '🧊'), ('ice', '❄️')),
    'ground': (('sand', '🏜️'), ('mud', '🟤'), ('quake', '🌎'), ('earth', '🪨')),
    'rock': (('slide', '🪨'), ('stone', '🪨'), ('rock', '🪨')),
    'flying': (('wind', '🌪️'), ('gust', '💨'), ('hurricane', '🌪️'), ('air', '💨')),
    'poison': (('smog', '🟣'), ('sludge', '🟣'), ('toxic', '☠️')),
    'psychic': (('psy', '🔮'), ('mind', '🧠'), ('dream', '💫')),
    'bug': (('web', '🕸️'), ('swarm', '🐝'), ('bug', '🐛')),
    'ghost': (('shadow', '👻'), ('night', '🌑'), ('phantom', '👻')),
    'dragon': (('draco', '🐉'), ('dragon', '🐉'), ('rage', '🐲')),
    'steel': (('iron', '⚙️'), ('metal', '🛡️'), ('steel', '⚙️')),
    'fairy': (('moon', '🌙'), ('dazzl', '🌟'), ('charm', '💖')),
    'fighting': (('kick', '🦵'), ('punch', '🥊'), ('palm', '✋')),
    'dark': (('dark', '🌑'), ('night', '🌙'), ('snarl', '🐺')),
    'normal': (('swift', '⭐'), ('head', '💫'), ('slam', '💥')),
}

def move_emoji(typ, name):
    lowered = (name or '').lower()
    for token, emoji in MOVE_EMOJI.get(typ, ()):
        if token in lowered:
            return emoji
    return EMOJI.get(typ, '💥')

# Q is a tactical control slot.  Its exact control effect follows the move's
# elemental identity so every Pokémon can contribute something distinct even
# when the local learnset lacks a traditional status move.
CONTROL_BY_TYPE = {
    'normal': ('daze', '😵‍💫', 'PUSING', 1.6),
    'fire': ('burn', '🔥', 'TERBAKAR', 4.0),
    'water': ('slow', '💧', 'MELAMBAT', 3.4),
    'electric': ('stun', '⚡', 'STUN', 1.55),
    'grass': ('bind', '🌿', 'TERJERAT', 3.2),
    'ice': ('freeze', '🧊', 'BEKU', 1.35),
    'fighting': ('knockback', '💥', 'TERLEMPAR', 0.0),
    'poison': ('poison', '☠️', 'RACUN', 4.5),
    'ground': ('slow', '🟤', 'LUMPUR', 3.8),
    'flying': ('knockback', '🌪️', 'TERHEMPAS', 0.0),
    'psychic': ('confuse', '🔮', 'BINGUNG', 3.0),
    'bug': ('bind', '🕸️', 'TERJERAT', 3.5),
    'rock': ('entomb', '🪨', 'TERKUBUR BATU', 1.45),
    'ghost': ('fear', '👻', 'KETAKUTAN', 2.6),
    'dragon': ('intimidate', '🐉', 'ATK TURUN', 4.0),
    'dark': ('blind', '🌫️', 'PANDANGAN GELAP', 3.0),
    'steel': ('armor_break', '💥🛡️', 'DEF TURUN', 4.0),
    'fairy': ('charm', '💖', 'DAYA SERANG TURUN', 3.5),
}

ULTIMATE_VARIANTS = {
    # Three species-stable attack identities per type. The species id chooses
    # a variant so same-type Pokémon no longer all show one generic ultimate.
    'normal': (('Meteor Impact', '☄️', 'area'), ('Starfall Crash', '⭐', 'rush'), ('Comet Breaker', '💫', 'beam')),
    'fire': (('Inferno Nova', '🌋', 'area'), ('Solar Flare', '☀️', 'beam'), ('Blazing Meteor', '☄️', 'rush')),
    'water': (('Tidal Cataclysm', '🌊', 'wave'), ('Abyssal Torrent', '💦', 'beam'), ('Maelstrom Surge', '🌀', 'area')),
    'electric': (('Thunder Dominion', '⚡', 'beam'), ('Volt Storm', '🌩️', 'barrage'), ('Plasma Rush', '🔋', 'rush')),
    'grass': (('Verdant Tempest', '🌳', 'area'), ('Worldroot Bloom', '🌿', 'wave'), ('Solar Petal Burst', '🌸', 'barrage')),
    'ice': (('Absolute Zero', '🧊', 'area'), ('Glacier Lance', '❄️', 'beam'), ('Blizzard Rush', '🌨️', 'rush')),
    'fighting': (('Meteor Barrage', '🥊', 'rush'), ('Comet Fist', '👊', 'beam'), ('Impact Cyclone', '💥', 'barrage')),
    'poison': (('Venom Eclipse', '🟣', 'area'), ('Toxic Downpour', '☠️', 'barrage'), ('Sludge Vortex', '🧪', 'wave')),
    'ground': (('Continental Break', '🌎', 'area'), ('Faultline Surge', '🌋', 'wave'), ('Sandstorm Catapult', '🏜️', 'rush')),
    'flying': (('Skybreaker', '🌪️', 'rush'), ('Jetstream Dive', '💨', 'beam'), ('Cyclone Wingbeat', '🌀', 'barrage')),
    'psychic': (('Mind Collapse', '🧠', 'beam'), ('Astral Singularity', '🔮', 'area'), ('Dreamwave Nova', '💫', 'wave')),
    'bug': (('Swarm Eclipse', '🐝', 'barrage'), ('Silkstorm Snare', '🕸️', 'wave'), ('Primal Megahorn', '🐛', 'rush')),
    'rock': (('Mountain Fall', '⛰️', 'area'), ('Obsidian Breaker', '🪨', 'rush'), ('Meteorite Barrage', '☄️', 'barrage')),
    'ghost': (('Phantom Rift', '👻', 'beam'), ('Haunted Eclipse', '🌑', 'area'), ('Spectral Rush', '💀', 'rush')),
    'dragon': (('Draco Catastrophe', '🐉', 'beam'), ('Elder Dragon Nova', '🐲', 'area'), ('Dragonfire Tempest', '🔥', 'wave')),
    'dark': (('Nightfall Ruin', '🌑', 'area'), ('Shadow Fang Rush', '🐺', 'rush'), ('Eclipse Barrage', '🌘', 'barrage')),
    'steel': (('Iron Citadel', '⚙️', 'barrage'), ('Chrome Meteor', '🛡️', 'rush'), ('Titanium Beam', '🔩', 'beam')),
    'fairy': (('Starlight Verdict', '🌟', 'beam'), ('Moonlit Wish', '🌙', 'wave'), ('Prism Waltz', '💖', 'barrage')),
}

def control_for(move):
    """Return a Q-slot control descriptor for a real move."""
    effect, emoji, label, duration = CONTROL_BY_TYPE.get(move.get('type', 'normal'), CONTROL_BY_TYPE['normal'])
    return {'effect': effect, 'effect_emoji': emoji, 'effect_label': label,
            'effect_duration': duration, 'effect_chance': .72 if effect not in ('knockback',) else 1.0}

def decorate_ultimate(move, species_id=None):
    """Give R a type- and species-specific name, icon and animation lane."""
    result=dict(move)
    variants=ULTIMATE_VARIANTS.get(result.get('type', 'normal'), ULTIMATE_VARIANTS['normal'])
    # Fallback callers without an id retain the first canonical variant.
    index=int(species_id)%len(variants) if species_id is not None else 0
    title, emoji, style = variants[index]
    result.update(name=title, emoji=emoji, ultimate_style=style,
                  style='area' if style in ('area','barrage') else 'beam' if style=='beam' else 'projectile',
                  range=1100, cooldown=12.0, ultimate=True,
                  power=min(150,max(100,int(result.get('power',80)*1.25))))
    return result

def skill(move,ultimate=False):
    typ=move['type']['name']; name=move['name'];power=move.get('power') or 50
    status=move.get('damage_class',{}).get('name')=='status'
    melee=move.get('damage_class',{}).get('name')=='physical' and any(w in name for w in ('punch','kick','tackle','scratch','bite','slash','headbutt','claw','chop'))
    area=any(w in name for w in ('quake','surf','storm','blizzard','discharge','explosion'))
    beam=any(w in name for w in ('beam','flame','breath','pump'))
    # Skill icon follows the move's actual type. This also keeps coverage moves
    # on dual-type Pokémon honest: a secondary-type move carries its own icon.
    emoji=move_emoji(typ,name)
    return {'name':name.replace('-',' ').title(),'type':typ,'power':min(140,power),'accuracy':move.get('accuracy') or 100,
            'emoji':emoji,'damage_class':move.get('damage_class',{}).get('name','special'),
            'style':'status' if status else 'area' if area else 'beam' if beam else 'melee' if melee else 'projectile',
            'range':150 if melee else 410 if area else 610 if beam else 750,
            'cooldown':12 if ultimate else round(1.4+power/65+(0.7 if area else 0),1),'ultimate':ultimate}

def fighter_loadout(moves, species_id=None, native_types=None):
    """Build the same Q/W/E/R controls for offline, online, and bot fighters."""
    if not moves:
        return [], None
    moves=list(moves[:3])
    while len(moves)<3:moves.append(moves[-1])
    q,w,e=(skill(move) for move in moves)
    # Preserve each Pokémon's real move name/type/emoji, while making the
    # combat roles readable and predictable across every battle mode.
    q.update(style='projectile',range=max(420,q['range']),cooldown=max(6.0,q['cooldown']))
    q.update(control_for(q))
    w.update(style='melee',range=116,cooldown=max(1.7,min(3.2,w['cooldown'])))
    if e['style'] in ('melee','status'):e['style']='projectile'
    e.update(range=max(650,e['range']),cooldown=max(3.5,min(5.5,e['cooldown'])))
    # A few species have only one or two legal attacks, so their loadout must
    # reuse a move. Keep those role variants readable in the HUD.
    roles=('Control','Close Strike','Ranged Burst')
    names=[q['name'],w['name'],e['name']]
    for index,move in enumerate((q,w,e)):
        if names.count(move['name'])>1:
            move['name']=f"{move['name']} · {roles[index]}"
    native_types=set(native_types or ())
    ultimate_base=max((move for move in (q,w,e) if move['type'] in native_types),
                      key=lambda move:move['power'],default=e)
    ultimate=decorate_ultimate(ultimate_base,species_id)
    return [q,w,e],ultimate
