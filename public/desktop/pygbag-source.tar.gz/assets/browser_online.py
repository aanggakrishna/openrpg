"""Async browser transport for the existing OpenRPG room API."""
import asyncio
import json
import queue
import time


class OnlineClient:
    def __init__(self, url, profile):
        self.url = url.rstrip("/")
        self.profile = dict(profile)
        self.token = self.profile.get("token", "")
        self.commands = queue.Queue(maxsize=32)
        self.events = queue.SimpleQueue()
        self.keys = {}
        self.connected = False
        self.stopped = False
        self.last_input = 0.0
        self.pending = 0
        self.send("connect", profile=self.profile)

    def send(self, action, **kwargs):
        if action == "connect":
            body = kwargs.get("profile", self.profile)
        else:
            body = dict(action=action, **kwargs)
        try:
            self.commands.put_nowait((action, body))
        except queue.Full:
            self.events.put(("error", "Please wait for the previous actions"))

    def pump(self, dt=0):
        """Launch network tasks without blocking Pygame's frame loop."""
        if self.stopped:
            return
        if self.connected and time.monotonic() - self.last_input >= .085:
            self.last_input = time.monotonic()
            self.send("input", keys=dict(self.keys))
        if self.pending >= 2:
            return
        try:
            action, body = self.commands.get_nowait()
        except queue.Empty:
            return
        self.pending += 1
        asyncio.create_task(self._request(action, body))

    async def _request(self, action, body):
        try:
            from platform import window, ffi, jsiter
            path = "/connect" if action == "connect" else "/action"
            headers = {"Content-Type": "application/json"}
            if action != "connect" and self.token:
                headers["Authorization"] = "Bearer " + self.token
            options = ffi({"method": "POST", "headers": ffi(headers), "body": json.dumps(body)})
            response = await jsiter(window.fetch(self.url + path, options))
            data = await jsiter(response.json())
            if not response.ok:
                raise ValueError(data.get("error", "Online server refused the request"))
            if action == "connect":
                self.token = data.get("token", "")
                self.connected = True
                self.events.put(("connected", data))
            else:
                data["_action"] = action
                self.events.put(("state", data))
        except Exception as exc:
            message = str(exc)
            self.events.put(("disconnected" if action == "connect" else "error", message[:180]))
            if action == "connect":
                self.connected = False
        finally:
            self.pending = max(0, self.pending - 1)

    def close(self):
        if self.connected:
            asyncio.create_task(self._request("disconnect", {"action": "disconnect"}))
        self.connected = False
        self.stopped = True
