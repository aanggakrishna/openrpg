from pathlib import Path
class _Screen:
    def __init__(self, lines): self.display=[""]*lines; self.dirty=set(range(lines))
class BrowserTerminal:
    def __init__(self, project, columns=132, lines=36, shell=None):
        self.project=Path(project); self.columns=columns; self.lines=lines; self.screen=_Screen(lines); self.error=""; self.bytes_received=0; self.phone_marker=""; self.phone_command=""
    @property
    def shell_name(self): return "BROWSER"
    @property
    def running(self): return False
    def start(self): self.error="Terminal is available in the desktop edition."
    def close(self): pass
    def poll(self): pass
    def send(self, data): pass
    def paste(self, data): pass
    def scroll(self, amount): pass
    def return_to_bottom(self): pass
    def run_from_phone(self, command): return "Terminal is available in the desktop edition."
    def open_external(self): return "Terminal is available in the desktop edition."
