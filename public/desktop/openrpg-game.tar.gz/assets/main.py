"""Browser entry point for the shared desktop game engine."""
import asyncio
import json
import sys
from pathlib import Path
import pygame as pg
import browser_media


async def main():
    # Import after browser startup so failures are shown in the outer shell.
    from game_engine import Game, ROOT
    save_path = ROOT / ".openrpg" / "save.json"
    save_path.parent.mkdir(parents=True, exist_ok=True)
    if sys.platform == "emscripten":
        try:
            from platform import window
            cloud_save = window.parent.OPENRPG_WASM_SAVE
            if cloud_save:
                bundle = json.loads(str(cloud_save))
                files = bundle.get("files", {}) if bundle.get("format") == "openrpg-web-save-v1" else {}
                allowed = {"save.json", *(f"profiles/slot-{slot}.json" for slot in range(1, 5))}
                for relative, contents in files.items():
                    if relative in allowed:
                        target = save_path.parent / relative
                        target.parent.mkdir(parents=True, exist_ok=True)
                        target.write_text(str(contents), encoding="utf-8")
        except Exception:
            pass
    game = Game(ROOT / "computer-workspace", save_path=save_path)
    if sys.platform == "emscripten":
        try:
            from platform import window
            game.online_url = str(window.parent.OPENRPG_CONFIG.onlineServerUrl or "")
        except Exception:
            pass
    clock, last_save = pg.time.Clock(), 0.0

    def cloud_bundle():
        files = {}
        paths = [("save.json", save_path)]
        paths.extend((f"profiles/slot-{slot}.json", save_path.parent / "profiles" / f"slot-{slot}.json") for slot in range(1, 5))
        for relative, path in paths:
            try: files[relative] = path.read_text(encoding="utf-8")
            except OSError: pass
        return json.dumps({"format": "openrpg-web-save-v1", "files": files})

    try:
        while game.running:
            dt = min(.05, clock.tick(60) / 1000)
            for event in pg.event.get(): game.handle(event)
            game.update(dt); game.draw()
            if sys.platform == "emscripten" and game.playing:
                last_save += dt
                if last_save >= 15:
                    last_save = 0; game.save_current()
                    try:
                        from platform import window
                        window.parent.postMessage(json.dumps({"type":"openrpg-wasm-save", "save":cloud_bundle()}), "*")
                    except Exception: pass
            await asyncio.sleep(0)
            await browser_media.pump()
    finally:
        game.save_current()
        if sys.platform == "emscripten":
            try:
                from platform import window
                window.parent.postMessage(json.dumps({"type":"openrpg-wasm-save", "save":cloud_bundle()}), "*")
            except Exception: pass
        game.terminal.close(); pg.quit()

try:
    asyncio.run(main())
except Exception:
    # Keep startup failures visible in the web shell instead of leaving a blank
    # canvas. This also lets the authenticated parent page report the error.
    import traceback
    error = traceback.format_exc()
    print(error)
    if sys.platform == "emscripten":
        try:
            from platform import window
            window.document.getElementById("infobox").innerText = error
            window.document.getElementById("infobox").style.display = "block"
            window.parent.postMessage(json.dumps({"type": "openrpg-wasm-error", "error": error}), "*")
        except Exception:
            pass
