"""Authoritative 20 Hz battles; no display, audio or client supplied damage."""
import math
import secrets
from collections import deque
import random
import pokemon_db
from combat_rules import skill, fighter_loadout


def creature(ident, level, boss=False):
    data = pokemon_db.detail(ident) or {}
    stats = {s['stat']['name']: s['base_stat'] for s in data.get('stats', [])}
    hp = int((40 + stats.get('hp', 50) * .65 + level * 3) * (2.5 if boss else 1))
    moves = pokemon_db.loadout(ident)
    skills,ultimate=fighter_loadout(moves)
    return dict(id=ident, name=data.get('name', str(ident)).title(), level=level, hp=hp, maximum=hp,
                attack=stats.get('attack', 50) + level * 2, defense=stats.get('defense', 50) + level,
                moves=skills, ultimate=ultimate, boss=boss)


from world_regions import DUNGEON_BIOMES, CLIMATES

DUNGEON_ENCOUNTERS=(
    ((41,74,95,293),248), ((10,46,123,285),254), ((60,194,453,590),260),
    ((27,111,328,551),464), ((86,220,361,613),473), ((37,58,218,322),485),
    ((302,374,436,703),376), ((16,333,627,714),149), ((147,371,443,610),445),
    ((63,201,280,605),150),
)

class Battle:
    def __init__(self, teams, tier=0, rng=None):
        self.rng = rng or random.Random()
        self.ident = secrets.token_hex(8)
        self.events = deque(maxlen=32)
        self.sequence = 0
        self.tier = tier
        self.stage = 0
        self.remaining = 60.0 if not tier else 180.0
        self.intro = 3.0
        self.result = None
        self.age = 0.0
        self.shots = []
        self.effects = []
        self.biome=DUNGEON_BIOMES[max(0,min(9,tier-1))] if tier else 'crystal'
        weather_names,weights=CLIMATES[self.biome]
        weather=self.rng.choices(weather_names,weights=weights)[0]
        self.weather={'Cerah':'sun','Hujan':'rain','Salju':'snow','Berawan':'wind'}[weather]
        self.arena='water' if self.biome=='swamp' else 'sky' if self.biome=='sky' else 'grass' if self.biome=='forest' else 'rock'
        self.platforms = [(230, 100, 490), (455, 110, 405), (715, 110, 465), (930, 110, 385)]
        self.active_bots = []
        self.fighters = {}
        for index, (uid, team) in enumerate(teams.items()):
            self.fighters[uid] = self.fighter(team, 160 + index * 780, index if not tier else 0)
        if tier:
            self.wave()

    def emit(self,kind,**data):
        self.sequence+=1;self.events.append(dict(seq=self.sequence,kind=kind,**data))

    @staticmethod
    def fighter(team, x, side):
        return dict(team=team, slot=next((i for i,c in enumerate(team) if c['hp']>0),0), x=float(x), y=570., vy=0., side=side, facing=1 if side == 0 else -1,
                    energy=25., guard=False, cooldowns=[0., 0., 0., 0., 0.], keys={}, input_age=0., ai=0.,stun=0.)

    def wave(self):
        self.fighters = {k:v for k,v in self.fighters.items() if not k.startswith('bot:')}
        self.active_bots = []
        base = (self.tier - 1) * 10
        counts = [5, 3, 3, 1]
        # Bosses are chosen from high base-stat species, at the tier's top level.
        for i in range(counts[self.stage]):
            level = base + (10 if self.stage == 3 else self.stage * 3 + self.rng.randint(1, 3))
            pool,boss=DUNGEON_ENCOUNTERS[max(0,min(9,self.tier-1))]
            ident=boss if self.stage==3 else self.rng.choice(pool)
            self.fighters[f'bot:{i}'] = self.fighter([creature(ident, level, self.stage == 3)], 720+i*70, 1)
            attackers = 1 if self.stage == 3 else min(3, self.stage + 1)
            if len(self.active_bots) < attackers:
                self.active_bots.append(f'bot:{i}')
        self.remaining = 180.
        self.intro = 3.

    def control(self, uid, keys):
        if uid in self.fighters:
            f = self.fighters[uid]
            f['keys'] = {k:bool(keys.get(k)) for k in ('left','right','up','down','guard','a','q','w','e','r','1','2','3')}
            f['input_age'] = 0.

    def hit(self, attacker, target, power, ultimate=False, move=None):
        f, g = self.fighters[attacker], self.fighters[target]
        p, q = f['team'][f['slot']], g['team'][g['slot']]
        if q['hp'] <= 0:
            return
        attack_type=(move or {}).get('type','normal')
        defender_data=pokemon_db.detail(q['id']) or {}
        defender_types=tuple(t.get('type',{}).get('name','normal') for t in defender_data.get('types',[]))
        effectiveness=pokemon_db.effectiveness(attack_type,defender_types)
        damage = max(2, int(power * .20 * (p['attack'] + 80) / (q['defense'] + 80)))
        if p.get('boss'): damage = int(damage * 1.3)
        damage = int(damage * effectiveness)
        if g['guard'] and effectiveness != 0: damage = max(1, int(damage * (.40 if ultimate else .15)))
        q['hp'] = max(0, q['hp'] - damage)
        stunned=False
        if effectiveness>0 and move and move.get('stun_chance') and not g['guard'] and self.rng.random()<move['stun_chance']:
            g['stun']=self.rng.uniform(1.0,3.0);stunned=True
        self.emit('hit',pokemon=q['id'],type=attack_type,ultimate=ultimate,
                  emoji=(move or {}).get('emoji','💥'),stunned=stunned,effectiveness=effectiveness)
        f['energy'] = min(100, f['energy'] + (0 if ultimate else 7))
        label=('NO EFFECT' if effectiveness==0 else 'BLOCK' if g['guard'] else
               'SUPER!' if effectiveness>=2 else 'RESIST' if effectiveness<=.5 else str(damage))
        self.effects.append(dict(x=g['x'], y=g['y']-35, text=label, ttl=.5))
        if ultimate and effectiveness>0:
            self.effects.append(dict(x=g['x'],y=g['y']-45,text=(move or {}).get('emoji','💥'),ttl=.7,
                                     blast=True,type=(move or {}).get('type','normal')))
        if q['hp'] == 0:
            # Dungeon enemies enter one at a time. Keep later enemies visible
            # in the arena, but never let all of them attack together.
            if target in self.active_bots:
                self.active_bots.remove(target)
                attackers = 1 if self.stage == 3 else min(3, self.stage + 1)
                upcoming = next((uid for uid,v in self.fighters.items()
                                 if uid.startswith('bot:') and uid not in self.active_bots
                                 and v['team'][v['slot']]['hp'] > 0), None)
                if upcoming is not None and len(self.active_bots) < attackers:
                    self.active_bots.append(upcoming)
            live = next((i for i,c in enumerate(g['team']) if c['hp'] > 0), None)
            if live is not None:
                g['slot'] = live
                g['cooldowns'] = [1.]*5

    def attack(self, uid, slot):
        f = self.fighters[uid]; p = f['team'][f['slot']]
        ultimate=slot==4
        if f['stun']>0 or f['cooldowns'][slot] > 0 or (ultimate and f['energy'] < 100): return
        enemies = [(k,v) for k,v in self.fighters.items() if v['side'] != f['side'] and v['team'][v['slot']]['hp'] > 0]
        if not enemies: return
        target, g = min(enemies, key=lambda kv: math.hypot(kv[1]['x']-f['x'], kv[1]['y']-f['y']))
        move = dict(name='Punch',power=42,range=85,cooldown=.55,emoji='🥊',accuracy=100,type='normal',style='melee')
        if 1<=slot<=3 and p['moves']: move = p['moves'][slot-1]
        elif ultimate:move=p['ultimate'] or p['moves'][-1]
        f['cooldowns'][slot] = move['cooldown']
        self.emit('attack',type=move['type'],ultimate=ultimate,pokemon=p['id'],name=move['name'],emoji=move['emoji'])
        if ultimate:
            f['energy'] = 0
            self.effects.append(dict(x=640,y=230,text=p['name']+' — '+move['name'],ttl=.82,ultimate=p['id'],
                                     cutin=True,type=move['type'],emoji=move['emoji']))
        dx, dy = g['x']-f['x'], g['y']-f['y']; distance = max(1, math.hypot(dx,dy))
        f['facing'] = 1 if dx >= 0 else -1
        self.effects.append(dict(x=f['x']+f['facing']*30,y=f['y']-35,text=move['emoji'],ttl=.25))
        if self.rng.random()*100 > move['accuracy']:
            self.effects.append(dict(x=f['x'],y=f['y']-65,text='MISS',ttl=.5)); return
        power = move['power'] * (1.8 if ultimate else 1)
        favored = {'sun':'fire','rain':'water','snow':'ice','wind':'flying'}[self.weather]
        if move['type'] in (favored,self.arena): power *= 1.15
        if slot==0 or move['style'] == 'melee':
            if distance <= (85 if slot==0 else move['range']): self.hit(uid,target,power,ultimate,move)
            return
        speed=1100 if ultimate else 500 if move.get('stun_chance') else 420
        self.shots.append(dict(owner=uid,side=f['side'],x=f['x'],y=f['y']-30,vx=dx/distance*speed,vy=dy/distance*speed,
                               remaining=move['range'],emoji=move['emoji'],power=power,ultimate=ultimate,
                               type=move['type'],name=move['name'],style=move['style'],age=0.,windup=.78 if ultimate else 0.,stun_chance=move.get('stun_chance',0)))

    def tick(self, dt):
        if self.result: return
        self.age += dt
        if self.intro > 0:
            self.intro -= dt; return
        self.remaining -= dt
        for uid,f in self.fighters.items():
            p = f['team'][f['slot']]
            if p['hp'] <= 0: continue
            f['input_age'] += dt
            if f['input_age'] > .7: f['keys'] = {}
            if uid.startswith('bot:'):
                if self.tier and uid not in self.active_bots:
                    # Staggered dungeon encounter: reserve this fighter's AI
                    # until the currently active enemy is defeated.
                    f['guard'] = True
                    continue
                f['ai'] -= dt
                if f['ai'] <= 0:
                    targets = [v for v in self.fighters.values() if v['side'] == 0 and v['team'][v['slot']]['hp'] > 0]
                    if targets:
                        target = min(targets, key=lambda v: abs(v['x']-f['x']))
                        dx = target['x']-f['x']
                        f['keys'] = dict(left=dx < -100,right=dx > 100,up=target['y'] < f['y']-50 or self.rng.random()<.15,
                                         guard=self.rng.random()<.14,a=abs(dx)<90,q=self.rng.random()<.7,
                                         w=self.rng.random()<.65,e=self.rng.random()<.5,r=self.rng.random()<.08)
                    f['ai'] = self.rng.uniform(.25,.65)
            keys = f['keys'];f['stun']=max(0,f['stun']-dt); f['guard'] = bool(keys.get('guard')) and f['stun']<=0
            for i in range(3):
                if keys.get(str(i+1)) and i < len(f['team']) and f['team'][i]['hp'] > 0: f['slot'] = i
            movement = (int(keys.get('right',False))-int(keys.get('left',False))) if f['stun']<=0 else 0
            if movement: f['facing'] = movement
            f['x'] = max(40,min(1240,f['x']+movement*(90 if f['guard'] else 230)*dt))
            grounded = f['y'] >= 570 or any(x-12 <= f['x'] <= x+w+12 and abs(f['y']-y)<1 for x,w,y in self.platforms)
            if keys.get('up') and grounded and f['stun']<=0: f['vy'] = -465
            old_y = f['y']; f['vy'] += 1150*dt; f['y'] += f['vy']*dt
            if f['vy'] >= 0:
                for x,w,y in self.platforms:
                    if x-10 <= f['x'] <= x+w+10 and old_y <= y <= f['y']: f['y']=y;f['vy']=0
            if f['y'] >= 570: f['y']=570;f['vy']=0
            f['energy'] = min(100, f['energy']+dt*4)
            f['cooldowns'] = [max(0,c-dt) for c in f['cooldowns']]
            if f['stun']<=0:
                for key,slot in (('a',0),('q',1),('w',2),('e',3),('r',4)):
                    if keys.get(key) and not f['guard']: self.attack(uid,slot)
        for shot in list(self.shots):
            shot['age']+=dt
            if shot['age']<shot['windup']:continue
            shot['x'] += shot['vx']*dt; shot['y'] += shot['vy']*dt
            speed=math.hypot(shot['vx'],shot['vy']);shot['remaining']-=speed*dt
            hit = False
            for uid,f in self.fighters.items():
                if f['side'] != shot['side'] and f['team'][f['slot']]['hp'] > 0 and math.hypot(f['x']-shot['x'], f['y']-30-shot['y'])<(52 if shot['ultimate'] else 28):
                    self.hit(shot['owner'],uid,shot['power'],shot['ultimate'],shot);hit=True;break
            if hit or shot['remaining'] <= 0: self.shots.remove(shot)
        self.effects = [dict(e,ttl=e['ttl']-dt) for e in self.effects if e['ttl']>dt]
        sides = {f['side'] for f in self.fighters.values() if any(p['hp']>0 for p in f['team'])}
        if self.tier and sides == {0} and self.stage < 3:
            self.stage += 1;self.shots.clear();self.wave();return
        if len(sides) <= 1 or self.remaining <= 0:
            winner = next(iter(sides)) if len(sides)==1 else None
            if self.remaining <= 0 and not self.tier:
                score = {side:sum(p['hp']/p['maximum'] for f in self.fighters.values() if f['side']==side for p in f['team']) for side in (0,1)}
                winner = None if abs(score[0]-score[1])<.001 else max(score,key=score.get)
            drops=[]
            if self.tier and winner == 0 and self.stage == 3:
                level=self.tier*10
                table=[('Potion',max(1,level//10)),('Poké Ball',max(1,level//20))]
                if level >= 20: table.append(('Rare Candy',1))
                if level >= 50: table.append(('Star Piece',1))
                drops=[self.rng.choice(table)]
            self.result = dict(winner=winner, drops=drops, message='Victory' if self.tier and winner==0 else 'Battle finished')

    def snapshot(self):
        return dict(id=self.ident,events=list(self.events),fighters={uid:{k:v for k,v in f.items() if k not in ('keys','input_age','ai')} for uid,f in self.fighters.items()},
                    remaining=round(self.remaining,1),intro=round(self.intro,1),stage=self.stage,tier=self.tier,
                    shots=self.shots,effects=self.effects,platforms=self.platforms,weather=self.weather,arena=self.arena,
                    active_bots=self.active_bots,result=self.result)
